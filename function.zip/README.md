# Function-app-deploy-azure
Node project to deploy using function app in azure 
